#ifndef CONFIG_H
#define CONFIG_H

// WiFi credentials
#define WIFI_SSID "****************" //WIfi 2.4GHz only 
#define WIFI_PASSWORD "****************" // password wifi

// Telegram Bot
#define BOT_TOKEN "8178214418:AAGtdrt4zivRyKGXdulAqAzSBtEW3MZyj0I" // token from telegram bot

// Pins / settings
// #define LED_PIN 2

#endif
